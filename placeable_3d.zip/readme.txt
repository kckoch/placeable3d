# Placeable Items
# Created: 20/09/2023 [dd/mm/yyyy]
# Author: FoxyNoTail
# Version: 0.3.1
# Made for Minecraft Bedrock Edition 1.20.30
# For more info visit www.foxynotail.com 

WHAT'S NEW IN v0.3.1
------
Updated for Minecraft 1.20

Due to a bug in 1.19.20, items have been raised from the ground level by half a block.

Update: Item sizes are now 8x8 instead of 16x16 so that you can click on the edges of the block they're placed on.

Place any item in the game on the floor or wall and rotate them like they're in an invisible item frame.

Craft vanilla items into placeable items by combining them with a slime ball on a crafting table.


README
------
EXPERIMENTAL
============
Requires "Holiday Creator Features" experiments enabled on the world, realm or server that this add-on is running on.

How it works
===========

Warning
======
If you have placed layers in a world and then disable the add-on, then you will get chunk serialization errors as the game will not be able to find the data for the custom blocks that live in the world.


HELP & SUPPORT
------
For help and questions about Foxy's packs, please join the discord via the link below


LINKS
------
Discord: discord.gg/BqGKecr
YouTube: youtube.com/foxynotail
Twitch: twitch.tv/foxynotail
Twitter: twitter.com/FoxyNoTail
Website: www.foxynotail.com
